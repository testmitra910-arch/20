package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import com.example.data.local.SessionManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class SupabaseClientProvider(private val sessionManager: SessionManager) {

    private var currentApi: SupabaseApiService? = null
    private var lastUrl: String = ""
    private var lastKey: String = ""

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    fun getEffectiveUrl(): String {
        val (customUrl, _) = sessionManager.getSupabaseConfig()
        if (customUrl.isNotBlank()) return customUrl

        // Try BuildConfig
        try {
            val buildConfigField = BuildConfig::class.java.getField("SUPABASE_URL")
            val url = buildConfigField.get(null) as? String
            if (!url.isNullOrBlank() && !url.startsWith("YOUR_") && !url.contains("placeholder", ignoreCase = true)) {
                return url
            }
        } catch (_: Exception) {}

        return SessionManager.DEFAULT_SUPABASE_URL
    }

    fun getEffectiveAnonKey(): String {
        val (_, customKey) = sessionManager.getSupabaseConfig()
        if (customKey.isNotBlank()) return customKey

        // Try BuildConfig
        try {
            val buildConfigField = BuildConfig::class.java.getField("SUPABASE_ANON_KEY")
            val key = buildConfigField.get(null) as? String
            if (!key.isNullOrBlank() && !key.startsWith("YOUR_") && !key.contains("placeholder", ignoreCase = true)) {
                return key
            }
        } catch (_: Exception) {}

        return SessionManager.DEFAULT_SUPABASE_ANON_KEY
    }

    fun isConfigured(): Boolean {
        val url = getEffectiveUrl()
        val key = getEffectiveAnonKey()
        return url.isNotBlank() && key.isNotBlank()
    }

    @Synchronized
    fun getApiService(): SupabaseApiService {
        val rawUrl = getEffectiveUrl()
        val key = getEffectiveAnonKey()

        // Normalize URL to base with /rest/v1/
        val baseUrl = normalizeRestUrl(rawUrl)

        if (currentApi != null && baseUrl == lastUrl && key == lastKey) {
            return currentApi!!
        }

        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val authInterceptor = Interceptor { chain ->
            val original = chain.request()
            val requestBuilder = original.newBuilder()
                .header("apikey", key)
                .header("Authorization", "Bearer $key")
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .header("Prefer", "return=representation")

            val request = requestBuilder.build()
            chain.proceed(request)
        }

        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(loggingInterceptor)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(baseUrl.ifBlank { "https://placeholder.supabase.co/rest/v1/" })
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        lastUrl = baseUrl
        lastKey = key
        currentApi = retrofit.create(SupabaseApiService::class.java)
        return currentApi!!
    }

    private fun normalizeRestUrl(inputUrl: String): String {
        if (inputUrl.isBlank()) return "https://vyxcerbdrjjphhqoksup.supabase.co/rest/v1/"
        var url = inputUrl.trim().trimEnd('/')
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://$url"
        }
        if (!url.endsWith("/rest/v1")) {
            url = "$url/rest/v1/"
        } else {
            url = "$url/"
        }
        return url
    }
}
