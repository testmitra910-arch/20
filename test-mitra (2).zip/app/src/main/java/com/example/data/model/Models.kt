package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@JsonClass(generateAdapter = true)
data class User(
    @Json(name = "id") val id: Long? = null,
    @Json(name = "mobile_number") val mobileNumber: String,
    @Json(name = "password") val password: String? = null,
    @Json(name = "role") val role: String = "student",
    @Json(name = "device_id") val deviceId: String? = null
) {
    val isTeacherOrAdmin: Boolean
        get() = role.equals("teacher", ignoreCase = true) || role.equals("admin", ignoreCase = true)
}

@JsonClass(generateAdapter = true)
data class CreateUserRequest(
    @Json(name = "mobile_number") val mobileNumber: String,
    @Json(name = "password") val password: String,
    @Json(name = "role") val role: String = "student",
    @Json(name = "device_id") val deviceId: String? = null
)

@JsonClass(generateAdapter = true)
data class UpdateUserDeviceRequest(
    @Json(name = "device_id") val deviceId: String?
)

@JsonClass(generateAdapter = true)
data class TestItem(
    @Json(name = "id") val id: Long? = null,
    @Json(name = "test_name") val testName: String,
    @Json(name = "duration") val duration: Int, // duration in minutes
    @Json(name = "is_active") val isActive: Boolean? = true
) {
    val isTestActive: Boolean
        get() = isActive != false
}

@JsonClass(generateAdapter = true)
data class CreateTestRequest(
    @Json(name = "test_name") val testName: String,
    @Json(name = "duration") val duration: Int,
    @Json(name = "is_active") val isActive: Boolean = true
)

@JsonClass(generateAdapter = true)
data class UpdateTestStatusRequest(
    @Json(name = "is_active") val isActive: Boolean
)

@JsonClass(generateAdapter = true)
data class QuestionItem(
    @Json(name = "id") val id: Long? = null,
    @Json(name = "test_id") val testId: Long,
    @Json(name = "question_text") val questionText: String,
    @Json(name = "option_a") val optionA: String,
    @Json(name = "option_b") val optionB: String,
    @Json(name = "option_c") val optionC: String,
    @Json(name = "option_d") val optionD: String,
    @Json(name = "correct_option") val correctOption: String
) {
    fun normalizedCorrectOption(): String {
        val clean = correctOption.trim().uppercase()
        return when {
            clean == "A" || clean.endsWith("OPTION_A") || clean.endsWith("OPTION A") -> "A"
            clean == "B" || clean.endsWith("OPTION_B") || clean.endsWith("OPTION B") -> "B"
            clean == "C" || clean.endsWith("OPTION_C") || clean.endsWith("OPTION C") -> "C"
            clean == "D" || clean.endsWith("OPTION_D") || clean.endsWith("OPTION D") -> "D"
            clean.equals(optionA.trim(), ignoreCase = true) -> "A"
            clean.equals(optionB.trim(), ignoreCase = true) -> "B"
            clean.equals(optionC.trim(), ignoreCase = true) -> "C"
            clean.equals(optionD.trim(), ignoreCase = true) -> "D"
            else -> clean.take(1)
        }
    }

    fun getOptionText(optionLetter: String): String {
        return when (optionLetter.uppercase().trim()) {
            "A" -> optionA
            "B" -> optionB
            "C" -> optionC
            "D" -> optionD
            else -> ""
        }
    }
}

@JsonClass(generateAdapter = true)
data class CreateQuestionRequest(
    @Json(name = "test_id") val testId: Long,
    @Json(name = "question_text") val questionText: String,
    @Json(name = "option_a") val optionA: String,
    @Json(name = "option_b") val optionB: String,
    @Json(name = "option_c") val optionC: String,
    @Json(name = "option_d") val optionD: String,
    @Json(name = "correct_option") val correctOption: String
)

@JsonClass(generateAdapter = true)
data class ResultItem(
    @Json(name = "id") val id: Long? = null,
    @Json(name = "user_id") val userId: Long,
    @Json(name = "test_id") val testId: Long,
    @Json(name = "score") val score: Double = 0.0,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateResultRequest(
    @Json(name = "user_id") val userId: Long,
    @Json(name = "test_id") val testId: Long,
    @Json(name = "score") val score: Long
)

data class EnrichedResult(
    val id: Long?,
    val userId: Long,
    val userMobile: String,
    val testId: Long,
    val testName: String,
    val testDuration: Int,
    val score: Double,
    val createdAt: String? = null,
    val totalQuestions: Int? = null,
    val correctCount: Int? = null
) {
    fun isWithin24Hours(): Boolean {
        if (createdAt.isNullOrBlank()) return true
        val parsedDate = parseDate(createdAt) ?: return true
        val diffMs = System.currentTimeMillis() - parsedDate.time
        val twentyFourHoursMs = 24L * 60 * 60 * 1000L
        // Allow clock skew (up to 24h ahead) and up to 24 hours in the past
        return diffMs <= twentyFourHoursMs && diffMs >= -twentyFourHoursMs
    }

    fun isWithin30Days(): Boolean {
        if (createdAt.isNullOrBlank()) return true
        val parsedDate = parseDate(createdAt) ?: return true
        val diffMs = System.currentTimeMillis() - parsedDate.time
        val thirtyDaysMs = 30L * 24 * 60 * 60 * 1000L
        // Allow clock skew and up to 30 days in the past
        return diffMs <= thirtyDaysMs && diffMs >= -thirtyDaysMs
    }

    fun getFormattedDate(): String {
        if (createdAt.isNullOrBlank()) return "Today / આજે"
        val parsedDate = parseDate(createdAt) ?: return createdAt
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        return sdf.format(parsedDate)
    }

    fun getFormattedTime(): String {
        if (createdAt.isNullOrBlank()) return ""
        val parsedDate = parseDate(createdAt) ?: return ""
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        return sdf.format(parsedDate)
    }

    fun getFormattedDateTime(): String {
        if (createdAt.isNullOrBlank()) return "Just now / તાજેતરમાં"
        val parsedDate = parseDate(createdAt) ?: return createdAt
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        return sdf.format(parsedDate)
    }

    fun getFormattedTimeAgo(): String {
        if (createdAt.isNullOrBlank()) return "Just now / તાજેતરમાં"
        val parsedDate = parseDate(createdAt) ?: return createdAt
        val diffMs = System.currentTimeMillis() - parsedDate.time
        if (diffMs < 0) return "Just now / તાજેતરમાં"
        val minutes = diffMs / (60 * 1000)
        val hours = minutes / 60
        return when {
            minutes < 1 -> "Just now / હમણાં જ"
            minutes < 60 -> "$minutes min ago / $minutes મિનિટ પહેલા"
            hours < 24 -> "$hours hr ago / $hours કલાક પહેલા"
            else -> {
                val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                sdf.format(parsedDate)
            }
        }
    }

    private fun parseDate(dateStr: String): Date? {
        val formats = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSSSSS",
            "yyyy-MM-dd'T'HH:mm:ss.SSS",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd HH:mm:ss"
        )
        for (pattern in formats) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                return sdf.parse(dateStr)
            } catch (_: Exception) {}
        }
        return null
    }
}

data class QuestionAnswerState(
    val question: QuestionItem,
    val selectedOption: String? = null
) {
    val isAnswered: Boolean
        get() = !selectedOption.isNullOrBlank()

    val isCorrect: Boolean
        get() = selectedOption != null &&
                selectedOption.equals(question.normalizedCorrectOption(), ignoreCase = true)
}
