package com.example.data.remote

import com.example.data.model.CreateQuestionRequest
import com.example.data.model.CreateResultRequest
import com.example.data.model.CreateTestRequest
import com.example.data.model.CreateUserRequest
import com.example.data.model.QuestionItem
import com.example.data.model.ResultItem
import com.example.data.model.TestItem
import com.example.data.model.UpdateTestStatusRequest
import com.example.data.model.UpdateUserDeviceRequest
import com.example.data.model.User
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Query

interface SupabaseApiService {

    // USERS Table
    @GET("users")
    suspend fun getUserByMobile(
        @Query("mobile_number") mobileNumberFilter: String, // e.g. "eq.9876543210"
        @Query("select") select: String = "*"
    ): Response<List<User>>

    @GET("users")
    suspend fun getUserById(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Query("select") select: String = "*"
    ): Response<List<User>>

    @GET("users")
    suspend fun getAllUsers(
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.desc"
    ): Response<List<User>>

    @POST("users")
    suspend fun createUser(
        @Body user: CreateUserRequest
    ): Response<List<User>>

    @PATCH("users")
    suspend fun updateUserDeviceId(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Body body: UpdateUserDeviceRequest
    ): Response<List<User>>

    @DELETE("users")
    suspend fun deleteUser(
        @Query("id") idFilter: String // e.g. "eq.1"
    ): Response<Unit>

    // TESTS Table
    @GET("tests")
    suspend fun getTests(
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.desc"
    ): Response<List<TestItem>>

    @GET("tests")
    suspend fun getTestById(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Query("select") select: String = "*"
    ): Response<List<TestItem>>

    @POST("tests")
    suspend fun createTest(
        @Body test: CreateTestRequest
    ): Response<List<TestItem>>

    @PATCH("tests")
    suspend fun updateTestStatus(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Body body: UpdateTestStatusRequest
    ): Response<List<TestItem>>

    @DELETE("tests")
    suspend fun deleteTest(
        @Query("id") idFilter: String
    ): Response<Unit>

    // QUESTIONS Table
    @GET("questions")
    suspend fun getQuestionsForTest(
        @Query("test_id") testIdFilter: String, // e.g. "eq.1"
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.asc"
    ): Response<List<QuestionItem>>

    @GET("questions")
    suspend fun getAllQuestions(
        @Query("select") select: String = "*"
    ): Response<List<QuestionItem>>

    @POST("questions")
    suspend fun createQuestion(
        @Body question: CreateQuestionRequest
    ): Response<List<QuestionItem>>

    @DELETE("questions")
    suspend fun deleteQuestion(
        @Query("id") idFilter: String
    ): Response<Unit>

    // RESULTS Table
    @GET("results")
    suspend fun getResults(
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.desc"
    ): Response<List<ResultItem>>

    @GET("results")
    suspend fun getResultsForUser(
        @Query("user_id") userIdFilter: String, // e.g. "eq.1"
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.desc"
    ): Response<List<ResultItem>>

    @POST("results")
    suspend fun submitResult(
        @Body result: CreateResultRequest
    ): Response<List<ResultItem>>

    @DELETE("results")
    suspend fun deleteResult(
        @Query("id") idFilter: String
    ): Response<Unit>
}
