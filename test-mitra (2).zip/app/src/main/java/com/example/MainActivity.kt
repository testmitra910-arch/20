package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.local.SessionManager
import com.example.data.model.User
import com.example.data.remote.SupabaseClientProvider
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.NoInternetDialog
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.admin.AdminHomeScreen
import com.example.ui.screens.student.StudentHomeScreen
import com.example.ui.screens.student.TakeTestScreen
import com.example.ui.screens.student.TestResultScreen
import com.example.ui.theme.TestMitraTheme
import com.example.util.NetworkMonitor

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val sessionManager = SessionManager(applicationContext)
        val clientProvider = SupabaseClientProvider(sessionManager)
        val repository = TestMitraRepository(clientProvider)
        val networkMonitor = NetworkMonitor(applicationContext)

        setContent {
            TestMitraTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TestMitraApp(
                        sessionManager = sessionManager,
                        clientProvider = clientProvider,
                        repository = repository,
                        networkMonitor = networkMonitor
                    )
                }
            }
        }
    }
}

@Composable
fun TestMitraApp(
    sessionManager: SessionManager,
    clientProvider: SupabaseClientProvider,
    repository: TestMitraRepository,
    networkMonitor: NetworkMonitor
) {
    val navController = rememberNavController()
    val isOnlineState by networkMonitor.isOnlineFlow.collectAsState(
        initial = networkMonitor.isCurrentlyConnected()
    )
    var manualCheckTrigger by remember { mutableStateOf(0) }
    val effectiveIsOnline = isOnlineState || (manualCheckTrigger > 0 && networkMonitor.isCurrentlyConnected())

    Box(modifier = Modifier.fillMaxSize()) {
        NavHost(
            navController = navController,
            startDestination = "splash"
        ) {
            composable("splash") {
                SplashScreen(
                    sessionManager = sessionManager,
                    onNavigateToLogin = {
                        navController.navigate("login") {
                            popUpTo("splash") { inclusive = true }
                        }
                    },
                    onNavigateToStudentHome = {
                        navController.navigate("student_home") {
                            popUpTo("splash") { inclusive = true }
                        }
                    },
                    onNavigateToAdminHome = {
                        navController.navigate("admin_home") {
                            popUpTo("splash") { inclusive = true }
                        }
                    }
                )
            }

            composable("login") {
                LoginScreen(
                    repository = repository,
                    sessionManager = sessionManager,
                    clientProvider = clientProvider,
                    onLoginSuccess = { user ->
                        if (user.isTeacherOrAdmin) {
                            navController.navigate("admin_home") {
                                popUpTo("login") { inclusive = true }
                            }
                        } else {
                            navController.navigate("student_home") {
                                popUpTo("login") { inclusive = true }
                            }
                        }
                    }
                )
            }

            composable("student_home") {
                val user = sessionManager.getUser() ?: User(mobileNumber = "Student", role = "student")
                StudentHomeScreen(
                    user = user,
                    repository = repository,
                    sessionManager = sessionManager,
                    onStartTest = { testId, testName, duration ->
                        val encodedName = Uri.encode(testName)
                        navController.navigate("take_test/$testId/$encodedName/$duration")
                    },
                    onLogout = {
                        navController.navigate("login") {
                            popUpTo("student_home") { inclusive = true }
                        }
                    }
                )
            }

            composable(
                route = "take_test/{testId}/{testName}/{duration}",
                arguments = listOf(
                    navArgument("testId") { type = NavType.LongType },
                    navArgument("testName") { type = NavType.StringType },
                    navArgument("duration") { type = NavType.IntType }
                )
            ) { backStackEntry ->
                val testId = backStackEntry.arguments?.getLong("testId") ?: 0L
                val rawName = backStackEntry.arguments?.getString("testName") ?: "Test"
                val testName = Uri.decode(rawName)
                val duration = backStackEntry.arguments?.getInt("duration") ?: 15
                val user = sessionManager.getUser() ?: User(mobileNumber = "Student", role = "student")

                TakeTestScreen(
                    testId = testId,
                    testName = testName,
                    durationMinutes = duration,
                    user = user,
                    repository = repository,
                    onTestFinished = { tId, tName, total, correct, score, answersJson ->
                        val encName = Uri.encode(tName)
                        val encJson = Uri.encode(answersJson)
                        navController.navigate("test_result/$tId/$encName/$total/$correct/$score/$encJson") {
                            popUpTo("take_test/$tId/$rawName/$duration") { inclusive = true }
                        }
                    },
                    onCancelTest = {
                        navController.popBackStack()
                    }
                )
            }

            composable(
                route = "test_result/{testId}/{testName}/{totalQuestions}/{correctCount}/{score}/{answersJson}",
                arguments = listOf(
                    navArgument("testId") { type = NavType.LongType },
                    navArgument("testName") { type = NavType.StringType },
                    navArgument("totalQuestions") { type = NavType.IntType },
                    navArgument("correctCount") { type = NavType.IntType },
                    navArgument("score") { type = NavType.StringType },
                    navArgument("answersJson") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val testId = backStackEntry.arguments?.getLong("testId") ?: 0L
                val testName = Uri.decode(backStackEntry.arguments?.getString("testName") ?: "Test")
                val totalQuestions = backStackEntry.arguments?.getInt("totalQuestions") ?: 0
                val correctCount = backStackEntry.arguments?.getInt("correctCount") ?: 0
                val score = backStackEntry.arguments?.getString("score")?.toDoubleOrNull() ?: correctCount.toDouble()
                val answersJson = Uri.decode(backStackEntry.arguments?.getString("answersJson") ?: "{}")

                TestResultScreen(
                    testId = testId,
                    testName = testName,
                    totalQuestions = totalQuestions,
                    correctCount = correctCount,
                    score = score,
                    answersMapJson = answersJson,
                    repository = repository,
                    onBackToHome = {
                        navController.navigate("student_home") {
                            popUpTo("student_home") { inclusive = true }
                        }
                    },
                    onRetakeTest = {
                        val encodedName = Uri.encode(testName)
                        navController.navigate("take_test/$testId/$encodedName/15") {
                            popUpTo("student_home")
                        }
                    }
                )
            }

            composable("admin_home") {
                val user = sessionManager.getUser() ?: User(mobileNumber = "Admin", role = "teacher")
                AdminHomeScreen(
                    user = user,
                    repository = repository,
                    sessionManager = sessionManager,
                    onLogout = {
                        navController.navigate("login") {
                            popUpTo("admin_home") { inclusive = true }
                        }
                    }
                )
            }
        }

        // Global Internet Requirement Popup: Blocks screen if internet is unavailable
        if (!effectiveIsOnline) {
            NoInternetDialog(
                onRetry = {
                    manualCheckTrigger++
                }
            )
        }
    }
}
