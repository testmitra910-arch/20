package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// TEST MITRA Brand Colors
// Navy & Deep Blues
val MitraNavyDark = Color(0xFF0A192F)
val MitraNavyPrimary = Color(0xFF0F3460)
val MitraNavySecondary = Color(0xFF16213E)
val MitraBlueAccent = Color(0xFF1E88E5)
val MitraBlueLight = Color(0xFFE8F1FF)

// Vibrant Green (Brand Color)
val MitraGreen = Color(0xFF16A34A)
val MitraGreenLight = Color(0xFFDCFCE7)
val MitraGreenAccent = Color(0xFF22C55E)

// Warm Accents (Logo & Alerts)
val MitraOrange = Color(0xFFEA580C)
val MitraOrangeLight = Color(0xFFFFEDD5)
val MitraAmber = Color(0xFFD97706)

// Neutral & Backgrounds
val MitraBgLight = Color(0xFFF8FAFC)
val MitraCardLight = Color(0xFFFFFFFF)
val MitraBorder = Color(0xFFE2E8F0)
val MitraBorderFocus = Color(0xFF93C5FD)

// Text Colors
val MitraTextPrimary = Color(0xFF0F172A)
val MitraTextSecondary = Color(0xFF475569)
val MitraTextMuted = Color(0xFF94A3B8)

// Status Colors
val MitraError = Color(0xFFDC2626)
val MitraErrorLight = Color(0xFFFEE2E2)
val MitraSuccess = Color(0xFF16A34A)
val MitraSuccessLight = Color(0xFFDCFCE7)
val MitraWarning = Color(0xFFD97706)
val MitraWarningLight = Color(0xFFFEF3C7)
