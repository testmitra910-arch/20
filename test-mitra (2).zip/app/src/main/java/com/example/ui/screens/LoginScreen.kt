package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.SessionManager
import com.example.data.model.User
import com.example.data.remote.SupabaseClientProvider
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.components.SupabaseConfigDialog
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraErrorLight
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraNavyDark
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraOrange
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    repository: TestMitraRepository,
    sessionManager: SessionManager,
    clientProvider: SupabaseClientProvider,
    onLoginSuccess: (User) -> Unit
) {
    var mobileNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showConfigDialog by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val isConfigured = clientProvider.isConfigured()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier
            .fillMaxSize()
            .testTag("login_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MitraBgLight)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .imePadding()
                    .padding(horizontal = 20.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Header Logo Card
                Surface(
                    modifier = Modifier.size(110.dp),
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 6.dp
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_test_mitra_logo),
                        contentDescription = "TEST MITRA Logo",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "TEST MITRA",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MitraNavyPrimary,
                    letterSpacing = 1.sp
                )

                Text(
                    text = "ટેસ્ટ મિત્ર — MCQ Test Portal",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MitraGreen
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Login Form Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Login to Your Account\nખાતામાં લોગિન કરો",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraTextPrimary,
                            lineHeight = 22.sp
                        )

                        // Mobile Number Input
                        OutlinedTextField(
                            value = mobileNumber,
                            onValueChange = { input ->
                                // Numbers only, maximum 15 digits
                                if (input.all { it.isDigit() } && input.length <= 15) {
                                    mobileNumber = input
                                    errorMessage = null
                                }
                            },
                            label = { Text("Mobile Number / મોબાઇલ નંબર") },
                            placeholder = { Text("Enter mobile number") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = null,
                                    tint = MitraNavyPrimary
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Phone,
                                imeAction = ImeAction.Next
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("mobile_number_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MitraNavyPrimary,
                                unfocusedBorderColor = MitraBorder
                            )
                        )

                        // Password Input
                        OutlinedTextField(
                            value = password,
                            onValueChange = {
                                password = it
                                errorMessage = null
                            },
                            label = { Text("Password / પાસવર્ડ") },
                            placeholder = { Text("Enter password") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = MitraNavyPrimary
                                )
                            },
                            trailingIcon = {
                                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (isPasswordVisible) "Hide password" else "Show password",
                                        tint = MitraTextMuted
                                    )
                                }
                            },
                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    focusManager.clearFocus()
                                }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("password_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MitraNavyPrimary,
                                unfocusedBorderColor = MitraBorder
                            )
                        )

                        // Error Message Display
                        if (!errorMessage.isNullOrBlank()) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MitraErrorLight,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = errorMessage!!,
                                    color = MitraError,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(12.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        // Login Action Button (Safe Height & No Overlap)
                        MitraPrimaryButton(
                            text = "Login / લોગ ઇન",
                            onClick = {
                                focusManager.clearFocus()
                                val cleanMobile = mobileNumber.trim()
                                val cleanPassword = password.trim()

                                if (cleanMobile.isBlank()) {
                                    errorMessage = "Please enter your mobile number / મોબાઇલ નંબર દાખલ કરો"
                                    return@MitraPrimaryButton
                                }
                                if (cleanPassword.isBlank()) {
                                    errorMessage = "Please enter your password / પાસવર્ડ દાખલ કરો"
                                    return@MitraPrimaryButton
                                }

                                if (!clientProvider.isConfigured()) {
                                    showConfigDialog = true
                                    return@MitraPrimaryButton
                                }

                                isLoading = true
                                errorMessage = null

                                scope.launch {
                                    val currentDeviceId = sessionManager.getDeviceId()
                                    when (val result = repository.login(cleanMobile, cleanPassword, currentDeviceId)) {
                                        is Resource.Success -> {
                                            isLoading = false
                                            sessionManager.saveUser(result.data)
                                            onLoginSuccess(result.data)
                                        }
                                        is Resource.Error -> {
                                            isLoading = false
                                            errorMessage = if (result.isNetworkError) {
                                                "No internet connection. Please check your network and retry."
                                            } else {
                                                result.message
                                            }
                                        }
                                        else -> {
                                            isLoading = false
                                        }
                                    }
                                }
                            },
                            isLoading = isLoading,
                            icon = Icons.Default.Login,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "login_button"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Supabase Connection Status / Quick Config Affordance
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MitraBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier.size(10.dp),
                                shape = CircleShape,
                                color = if (isConfigured) MitraGreen else MitraOrange
                            ) {}
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isConfigured) "Supabase: Connected" else "Supabase: Setup Required",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = MitraTextSecondary
                            )
                        }

                        TextButton(
                            onClick = { showConfigDialog = true },
                            modifier = Modifier.testTag("open_supabase_config_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = MitraNavyPrimary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Settings",
                                fontSize = 12.sp,
                                color = MitraNavyPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    if (showConfigDialog) {
        val (currentUrl, currentKey) = sessionManager.getSupabaseConfig()
        SupabaseConfigDialog(
            initialUrl = currentUrl.ifBlank { clientProvider.getEffectiveUrl() },
            initialKey = currentKey.ifBlank { clientProvider.getEffectiveAnonKey() },
            repository = repository,
            onSave = { newUrl, newKey ->
                sessionManager.saveSupabaseConfig(newUrl, newKey)
            },
            onDismiss = { showConfigDialog = false }
        )
    }
}
