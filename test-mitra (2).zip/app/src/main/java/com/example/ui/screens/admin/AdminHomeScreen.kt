package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SessionManager
import com.example.data.model.EnrichedResult
import com.example.data.model.QuestionItem
import com.example.data.model.TestItem
import com.example.data.model.User
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraOutlinedButton
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.components.MitraSuccessButton
import com.example.ui.components.OfflineErrorCard
import com.example.ui.components.SupabaseConfigDialog
import com.example.ui.components.TestMitraTopBar
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraErrorLight
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyDark
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraOrange
import com.example.ui.theme.MitraOrangeLight
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHomeScreen(
    user: User,
    repository: TestMitraRepository,
    sessionManager: SessionManager,
    onLogout: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var testsList by remember { mutableStateOf<List<TestItem>>(emptyList()) }
    var usersList by remember { mutableStateOf<List<User>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showConfigDialog by remember { mutableStateOf(false) }

    // Dialog state for viewing questions of a test
    var viewingQuestionsTest by remember { mutableStateOf<TestItem?>(null) }
    var testQuestionsList by remember { mutableStateOf<List<QuestionItem>>(emptyList()) }
    var isLoadingQuestions by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    fun loadAllData() {
        isLoading = true
        errorMessage = null
        scope.launch {
            val testsRes = repository.getTests()
            val usersRes = repository.getAllUsers()

            isLoading = false
            when {
                testsRes is Resource.Success -> {
                    testsList = testsRes.data
                    if (usersRes is Resource.Success) {
                        usersList = usersRes.data
                    }
                }
                testsRes is Resource.Error -> {
                    errorMessage = testsRes.message
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        loadAllData()
    }

    Scaffold(
        topBar = {
            TestMitraTopBar(
                title = "TEST MITRA",
                subtitle = "Teacher & Admin • ${user.mobileNumber}",
                userRole = "Teacher/Admin",
                onRefresh = { loadAllData() },
                onOpenSettings = { showConfigDialog = true },
                onLogout = {
                    sessionManager.clearSession()
                    onLogout()
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_home_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MitraBgLight)
        ) {
            when {
                isLoading && testsList.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = MitraNavyPrimary)
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Connecting to Supabase...\nડેટા મેળવી રહ્યા છીએ...",
                                color = MitraTextSecondary,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                errorMessage != null -> {
                    OfflineErrorCard(
                        errorMessage = errorMessage,
                        onRetry = { loadAllData() },
                        onOpenSettings = { showConfigDialog = true }
                    )
                }

                else -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        val studentCount = usersList.count { !it.isTeacherOrAdmin }

                        // 3 Navigation Tabs: Tests, Students, Create/Add
                        SecondaryTabRow(
                            selectedTabIndex = selectedTab,
                            containerColor = Color.White,
                            contentColor = MitraNavyPrimary,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Tab(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                text = {
                                    Text(
                                        text = "Tests (${testsList.size})\nટેસ્ટ",
                                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                },
                                modifier = Modifier.testTag("admin_tab_tests")
                            )
                            Tab(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                text = {
                                    Text(
                                        text = "Students ($studentCount)\nવિદ્યાર્થીઓ",
                                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                },
                                modifier = Modifier.testTag("admin_tab_students")
                            )
                            Tab(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                text = {
                                    Text(
                                        text = "Create / Add\nનવું ઉમેરો",
                                        fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                },
                                modifier = Modifier.testTag("admin_tab_add")
                            )
                        }

                        // Tab 0: Tests Management
                        if (selectedTab == 0) {
                            if (testsList.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "No Tests Created Yet",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MitraTextPrimary
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Go to 'Create / Add' tab to create your first test.",
                                            fontSize = 13.sp,
                                            color = MitraTextSecondary
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        MitraPrimaryButton(
                                            text = "Create Test Now / ટેસ્ટ બનાવો",
                                            onClick = { selectedTab = 2 }
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("admin_tests_list"),
                                    contentPadding = PaddingValues(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    items(testsList, key = { it.id ?: 0L }) { test ->
                                        AdminTestItemCard(
                                            test = test,
                                            onToggleActive = { newStatus ->
                                                // Optimistic update
                                                testsList = testsList.map {
                                                    if (it.id == test.id) it.copy(isActive = newStatus) else it
                                                }
                                                scope.launch {
                                                    val res = repository.updateTestStatus(test.id ?: 0L, newStatus)
                                                    if (res is Resource.Success) {
                                                        val statusText = if (newStatus) "Active (ચાલુ)" else "Deactive (બંધ)"
                                                        snackbarHostState.showSnackbar("ટેસ્ટ સ્થિતિ બદલાઈ: $statusText")
                                                    } else if (res is Resource.Error) {
                                                        snackbarHostState.showSnackbar(res.message)
                                                        loadAllData()
                                                    }
                                                }
                                            },
                                            onViewQuestions = {
                                                viewingQuestionsTest = test
                                                isLoadingQuestions = true
                                                scope.launch {
                                                    val qRes = repository.getQuestionsForTest(test.id ?: 0L)
                                                    isLoadingQuestions = false
                                                    if (qRes is Resource.Success) {
                                                        testQuestionsList = qRes.data
                                                    }
                                                }
                                            },
                                            onDelete = {
                                                scope.launch {
                                                    val delRes = repository.deleteTest(test.id ?: 0L)
                                                    if (delRes is Resource.Success) {
                                                        snackbarHostState.showSnackbar("Test deleted successfully / ટેસ્ટ કાઢી નાખવામાં આવ્યો")
                                                        loadAllData()
                                                    } else if (delRes is Resource.Error) {
                                                        snackbarHostState.showSnackbar(delRes.message)
                                                    }
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Tab 1: Students Management Section
                        else if (selectedTab == 1) {
                            AdminStudentsSection(
                                usersList = usersList,
                                repository = repository,
                                onStudentAdded = {
                                    loadAllData()
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Student added successfully! / વિદ્યાર્થી સફળતાપૂર્વક ઉમેરાઈ ગયો!")
                                    }
                                },
                                onStudentDeleted = {
                                    loadAllData()
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Student removed! / વિદ્યાર્થી કાઢી નાખવામાં આવ્યો!")
                                    }
                                }
                            )
                        }

                        // Tab 2: Create Test & Add Question Forms
                        else if (selectedTab == 2) {
                            AdminCreateContentSection(
                                testsList = testsList,
                                repository = repository,
                                onTestCreated = {
                                    loadAllData()
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Test created successfully! / નવો ટેસ્ટ ઉમેરાઈ ગયો!")
                                    }
                                },
                                onQuestionAdded = {
                                    loadAllData()
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Question saved to Supabase! / પ્રશ્ન સાચવી લીધો!")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal: View & Manage Questions for a specific test
    if (viewingQuestionsTest != null) {
        val test = viewingQuestionsTest!!
        AlertDialog(
            onDismissRequest = { viewingQuestionsTest = null },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp)
                .testTag("admin_view_questions_dialog"),
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = test.testName,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraNavyPrimary
                        )
                        Text(
                            text = "Total Questions: ${testQuestionsList.size}",
                            fontSize = 12.sp,
                            color = MitraTextSecondary
                        )
                    }
                    IconButton(onClick = { viewingQuestionsTest = null }) {
                        Icon(Icons.Default.Clear, contentDescription = "Close")
                    }
                }
            },
            text = {
                Box(modifier = Modifier.height(400.dp)) {
                    if (isLoadingQuestions) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = MitraNavyPrimary)
                        }
                    } else if (testQuestionsList.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = "No questions added to this test yet.\nઆ ટેસ્ટમાં હજુ કોઈ પ્રશ્નો ઉમેરેલ નથી.",
                                textAlign = TextAlign.Center,
                                color = MitraTextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(testQuestionsList, key = { it.id ?: 0L }) { q ->
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MitraBgLight),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Text(
                                                text = q.questionText,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 14.sp,
                                                color = MitraTextPrimary,
                                                modifier = Modifier.weight(1f)
                                            )
                                            IconButton(
                                                onClick = {
                                                    val qId = q.id
                                                    if (qId != null) {
                                                        scope.launch {
                                                            val delQ = repository.deleteQuestion(qId)
                                                            if (delQ is Resource.Success) {
                                                                testQuestionsList = testQuestionsList.filter { it.id != qId }
                                                            }
                                                        }
                                                    }
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Delete Question",
                                                    tint = MitraError,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        // Options preview
                                        val correct = q.normalizedCorrectOption()
                                        listOf(
                                            "A" to q.optionA,
                                            "B" to q.optionB,
                                            "C" to q.optionC,
                                            "D" to q.optionD
                                        ).forEach { (opt, txt) ->
                                            val isCorrect = opt.equals(correct, ignoreCase = true)
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (isCorrect) MitraGreenLight else Color.White,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 2.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "($opt) $txt",
                                                        fontSize = 12.sp,
                                                        fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal,
                                                        color = if (isCorrect) MitraGreen else MitraTextSecondary
                                                    )
                                                    if (isCorrect) {
                                                        Spacer(modifier = Modifier.weight(1f))
                                                        Text("✓ Correct", fontSize = 11.sp, color = MitraGreen, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Close / બંધ કરો",
                    onClick = { viewingQuestionsTest = null }
                )
            }
        )
    }

    if (showConfigDialog) {
        val (currentUrl, currentKey) = sessionManager.getSupabaseConfig()
        SupabaseConfigDialog(
            initialUrl = currentUrl,
            initialKey = currentKey,
            repository = repository,
            onSave = { newUrl, newKey ->
                sessionManager.saveSupabaseConfig(newUrl, newKey)
                loadAllData()
            },
            onDismiss = { showConfigDialog = false }
        )
    }
}

@Composable
private fun AdminStudentsSection(
    usersList: List<User>,
    repository: TestMitraRepository,
    onStudentAdded: () -> Unit,
    onStudentDeleted: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var userToDelete by remember { mutableStateOf<User?>(null) }
    val scope = rememberCoroutineScope()

    val students = remember(usersList, searchQuery) {
        val list = usersList.filter { !it.isTeacherOrAdmin }
        if (searchQuery.isBlank()) list
        else list.filter { it.mobileNumber.contains(searchQuery.trim()) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Action Bar: Search + Add Student Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by mobile...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = MitraNavyPrimary)
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("search_student_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MitraNavyPrimary,
                    unfocusedBorderColor = MitraBorder,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )

            MitraSuccessButton(
                text = "Add / ઉમેરો",
                onClick = { showAddDialog = true },
                icon = Icons.Default.PersonAdd,
                height = 54.dp,
                testTag = "open_add_student_button"
            )
        }

        // Header Info
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.People,
                            contentDescription = null,
                            tint = MitraNavyPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "નોંધાયેલા વિદ્યાર્થીઓ",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraTextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Students Management (${students.size})",
                        fontSize = 12.sp,
                        color = MitraTextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MitraGreenLight
                ) {
                    Text(
                        text = "${students.size} Active",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraGreen,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Students List
        if (students.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.People,
                        contentDescription = null,
                        tint = MitraTextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "કોઈ વિદ્યાર્થી મળ્યો નથી.\n(No students match search)"
                        else "હજુ સુધી કોઈ વિદ્યાર્થી ઉમેરાયેલ નથી.\nઉપરના '+ Add / ઉમેરો' બટન પરથી વિદ્યાર્થી ઉમેરો.",
                        fontSize = 14.sp,
                        color = MitraTextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("admin_students_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(students, key = { it.id ?: 0L }) { student ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("student_card_${student.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    modifier = Modifier.size(44.dp),
                                    shape = CircleShape,
                                    color = MitraNavyPrimary.copy(alpha = 0.1f)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.People,
                                            contentDescription = null,
                                            tint = MitraNavyPrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = student.mobileNumber,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MitraTextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Role: Student • ID #${student.id ?: "-"}",
                                        fontSize = 11.sp,
                                        color = MitraTextSecondary
                                    )
                                }
                            }

                            IconButton(
                                onClick = { userToDelete = student },
                                modifier = Modifier.testTag("delete_student_btn_${student.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete Student",
                                    tint = MitraError
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Add New Student
    if (showAddDialog) {
        var mobileInput by remember { mutableStateOf("") }
        var passwordInput by remember { mutableStateOf("") }
        var isPasswordVisible by remember { mutableStateOf(false) }
        var isSaving by remember { mutableStateOf(false) }
        var addError by remember { mutableStateOf<String?>(null) }
        val focusManager = LocalFocusManager.current

        AlertDialog(
            onDismissRequest = { if (!isSaving) showAddDialog = false },
            modifier = Modifier.testTag("add_student_dialog"),
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PersonAdd,
                        contentDescription = null,
                        tint = MitraNavyPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Add Student / નવો સ્ટુડન્ટ",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraTextPrimary
                        )
                        Text(
                            text = "વિદ્યાર્થીનો મોબાઈલ અને પાસવર્ડ દાખલ કરો",
                            fontSize = 12.sp,
                            color = MitraTextSecondary
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = mobileInput,
                        onValueChange = { input ->
                            if (input.all { it.isDigit() } && input.length <= 10) {
                                mobileInput = input
                                addError = null
                            }
                        },
                        label = { Text("Mobile Number (10 Digits)") },
                        placeholder = { Text("e.g. 9876543210") },
                        leadingIcon = {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = MitraNavyPrimary)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_student_mobile_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = {
                            passwordInput = it
                            addError = null
                        },
                        label = { Text("Login Password / પાસવર્ડ") },
                        placeholder = { Text("Enter student password") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = MitraNavyPrimary)
                        },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle visibility"
                                )
                            }
                        },
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_student_password_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    if (addError != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MitraErrorLight,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = addError!!,
                                color = MitraError,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Save Student / સાચવો",
                    onClick = {
                        focusManager.clearFocus()
                        if (mobileInput.length != 10) {
                            addError = "કૃપા કરીને ૧૦ અંકનો મોબાઈલ નંબર દાખલ કરો (Enter valid 10-digit number)"
                            return@MitraPrimaryButton
                        }
                        if (passwordInput.isBlank()) {
                            addError = "કૃપા કરીને પાસવર્ડ દાખલ કરો (Enter password)"
                            return@MitraPrimaryButton
                        }

                        isSaving = true
                        addError = null
                        scope.launch {
                            val res = repository.registerUser(mobileInput, passwordInput, role = "student")
                            isSaving = false
                            if (res is Resource.Success) {
                                showAddDialog = false
                                onStudentAdded()
                            } else if (res is Resource.Error) {
                                addError = res.message
                            }
                        }
                    },
                    isLoading = isSaving,
                    icon = Icons.Default.CheckCircle,
                    testTag = "save_student_confirm_btn"
                )
            },
            dismissButton = {
                TextButton(
                    onClick = { if (!isSaving) showAddDialog = false },
                    enabled = !isSaving
                ) {
                    Text("Cancel / રદ કરો")
                }
            }
        )
    }

    // Modal: Confirm Delete Student
    if (userToDelete != null) {
        val student = userToDelete!!
        AlertDialog(
            onDismissRequest = { userToDelete = null },
            title = { Text("Delete Student? / વિદ્યાર્થી કાઢી નાખવો છે?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to remove student with mobile number ${student.mobileNumber}? The student will be logged out automatically.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        val sId = student.id
                        userToDelete = null
                        if (sId != null) {
                            scope.launch {
                                repository.deleteUser(sId)
                                onStudentDeleted()
                            }
                        }
                    },
                    modifier = Modifier.testTag("confirm_delete_student_button")
                ) {
                    Text("Delete / કાઢી નાખો", color = MitraError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { userToDelete = null }) {
                    Text("Cancel / રદ કરો")
                }
            }
        )
    }
}

@Composable
private fun AdminTestItemCard(
    test: TestItem,
    onToggleActive: (Boolean) -> Unit,
    onViewQuestions: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }
    val isActive = test.isTestActive

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_test_card_${test.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = test.testName,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Duration: ${test.duration} minutes",
                        fontSize = 12.sp,
                        color = MitraTextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isActive) MitraGreenLight else MitraBgLight
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(if (isActive) MitraGreen else MitraTextMuted, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isActive) "Active (ચાલુ)" else "Deactive (બંધ)",
                            color = if (isActive) MitraGreen else MitraTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Active / Deactive Toggle Switch Row
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MitraBgLight,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isActive) Icons.Default.PlayCircle else Icons.Default.PauseCircle,
                            contentDescription = null,
                            tint = if (isActive) MitraGreen else MitraTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isActive) "Test Status: Active (ટેસ્ટ ચાલુ છે)" else "Test Status: Deactive (ટેસ્ટ બંધ છે)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isActive) MitraGreen else MitraTextSecondary
                        )
                    }

                    Switch(
                        checked = isActive,
                        onCheckedChange = { onToggleActive(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = MitraGreen,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = MitraBorder
                        ),
                        modifier = Modifier.testTag("toggle_test_active_${test.id}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MitraOutlinedButton(
                    text = "View Questions",
                    onClick = onViewQuestions,
                    icon = Icons.Default.FormatListNumbered,
                    modifier = Modifier.weight(1f),
                    height = 44.dp,
                    testTag = "view_questions_button_${test.id}"
                )

                MitraOutlinedButton(
                    text = "Delete",
                    onClick = { showDeleteConfirm = true },
                    icon = Icons.Default.Delete,
                    borderColor = MitraErrorLight,
                    contentColor = MitraError,
                    modifier = Modifier.weight(0.7f),
                    height = 44.dp,
                    testTag = "delete_test_button_${test.id}"
                )
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Test? / ટેસ્ટ કાઢી નાખવો છે?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete '${test.testName}'? All associated questions will also be removed.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    modifier = Modifier.testTag("confirm_delete_test_button")
                ) {
                    Text("Delete / કાઢી નાખો", color = MitraError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel / રદ કરો")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminCreateContentSection(
    testsList: List<TestItem>,
    repository: TestMitraRepository,
    onTestCreated: () -> Unit,
    onQuestionAdded: () -> Unit
) {
    var subTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Toggle subtab: New Test vs New Question
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MitraBgLight,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(modifier = Modifier.padding(4.dp)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (subTab == 0) Color.White else Color.Transparent,
                    shadowElevation = if (subTab == 0) 2.dp else 0.dp,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    TextButton(
                        onClick = { subTab = 0 },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Quiz, contentDescription = null, tint = MitraNavyPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "1. New Test",
                            color = MitraNavyPrimary,
                            fontWeight = if (subTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (subTab == 1) Color.White else Color.Transparent,
                    shadowElevation = if (subTab == 1) 2.dp else 0.dp,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    TextButton(
                        onClick = { subTab = 1 },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = MitraNavyPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "2. Add Question",
                            color = MitraNavyPrimary,
                            fontWeight = if (subTab == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (subTab == 0) {
            CreateTestForm(
                repository = repository,
                onTestCreated = {
                    onTestCreated()
                    subTab = 1 // Automatically move to add question
                }
            )
        } else {
            AddQuestionForm(
                testsList = testsList,
                repository = repository,
                onQuestionAdded = onQuestionAdded
            )
        }
    }
}

@Composable
private fun CreateTestForm(
    repository: TestMitraRepository,
    onTestCreated: () -> Unit
) {
    var testName by remember { mutableStateOf("") }
    var durationText by remember { mutableStateOf("15") }
    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_create_test_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Create New MCQ Test\nનવો એમસીક્યુ ટેસ્ટ બનાવો",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MitraNavyPrimary
            )

            OutlinedTextField(
                value = testName,
                onValueChange = {
                    testName = it
                    errorMessage = null
                },
                label = { Text("Test Name / વિષય / ટેસ્ટનું નામ") },
                placeholder = { Text("e.g. Gujarati Grammar Chapter 1") },
                leadingIcon = {
                    Icon(Icons.Default.Quiz, contentDescription = null, tint = MitraNavyPrimary)
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("create_test_name_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MitraNavyPrimary,
                    unfocusedBorderColor = MitraBorder
                )
            )

            OutlinedTextField(
                value = durationText,
                onValueChange = {
                    if (it.all { char -> char.isDigit() }) {
                        durationText = it
                        errorMessage = null
                    }
                },
                label = { Text("Duration (Minutes) / સમય (મિનિટ)") },
                placeholder = { Text("15") },
                leadingIcon = {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = MitraNavyPrimary)
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("create_test_duration_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MitraNavyPrimary,
                    unfocusedBorderColor = MitraBorder
                )
            )

            if (!errorMessage.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MitraErrorLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = errorMessage!!,
                        color = MitraError,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            MitraPrimaryButton(
                text = "Save Test & Continue / સાચવો",
                onClick = {
                    focusManager.clearFocus()
                    val cleanName = testName.trim()
                    val duration = durationText.toIntOrNull() ?: 0

                    if (cleanName.isBlank()) {
                        errorMessage = "કૃપા કરીને ટેસ્ટનું નામ દાખલ કરો (Please enter test name)"
                        return@MitraPrimaryButton
                    }
                    if (duration <= 0) {
                        errorMessage = "કૃપા કરીને સમય મિનિટમાં દાખલ કરો (Duration must be > 0)"
                        return@MitraPrimaryButton
                    }

                    isSaving = true
                    errorMessage = null
                    scope.launch {
                        val res = repository.createTest(cleanName, duration)
                        isSaving = false
                        if (res is Resource.Success) {
                            testName = ""
                            durationText = "15"
                            onTestCreated()
                        } else if (res is Resource.Error) {
                            errorMessage = res.message
                        }
                    }
                },
                isLoading = isSaving,
                icon = Icons.Default.CheckCircle,
                modifier = Modifier.fillMaxWidth(),
                testTag = "save_test_button"
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddQuestionForm(
    testsList: List<TestItem>,
    repository: TestMitraRepository,
    onQuestionAdded: () -> Unit
) {
    var selectedTestId by remember { mutableStateOf<Long?>(testsList.firstOrNull()?.id) }
    var isDropdownExpanded by remember { mutableStateOf(false) }

    var questionText by remember { mutableStateOf("") }
    var optionA by remember { mutableStateOf("") }
    var optionB by remember { mutableStateOf("") }
    var optionC by remember { mutableStateOf("") }
    var optionD by remember { mutableStateOf("") }
    var correctOption by remember { mutableStateOf("A") }

    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    LaunchedEffect(testsList) {
        if (selectedTestId == null && testsList.isNotEmpty()) {
            selectedTestId = testsList.first().id
        }
    }

    if (testsList.isEmpty()) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "પ્રથમ ટેસ્ટ બનાવો (Create a test first)",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MitraNavyPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "પ્રશ્નો ઉમેરતા પહેલા '1. New Test' પર જઈને ટેસ્ટ બનાવો.",
                    fontSize = 13.sp,
                    color = MitraTextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }
        return
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_add_question_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Add Question to Test\nટેસ્ટમાં નવો પ્રશ્ન ઉમેરો",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MitraNavyPrimary
            )

            // Select Test Dropdown
            val currentSelectedTest = testsList.firstOrNull { it.id == selectedTestId }
            ExposedDropdownMenuBox(
                expanded = isDropdownExpanded,
                onExpandedChange = { isDropdownExpanded = !isDropdownExpanded }
            ) {
                OutlinedTextField(
                    value = currentSelectedTest?.testName ?: "Select Test / ટેસ્ટ પસંદ કરો",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Select Test / કયા ટેસ્ટમાં પ્રશ્ન ઉમેરવો છે?") },
                    trailingIcon = {
                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDropdownExpanded)
                    },
                    modifier = Modifier
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable, enabled = true)
                        .fillMaxWidth()
                        .testTag("select_test_dropdown"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MitraNavyPrimary,
                        unfocusedBorderColor = MitraBorder
                    )
                )

                ExposedDropdownMenu(
                    expanded = isDropdownExpanded,
                    onDismissRequest = { isDropdownExpanded = false }
                ) {
                    testsList.forEach { t ->
                        DropdownMenuItem(
                            text = { Text(t.testName) },
                            onClick = {
                                selectedTestId = t.id
                                isDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            // Question Text Input
            OutlinedTextField(
                value = questionText,
                onValueChange = {
                    questionText = it
                    errorMessage = null
                    successMessage = null
                },
                label = { Text("Question Text / પ્રશ્ન") },
                placeholder = { Text("Enter question here...") },
                minLines = 2,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("question_text_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MitraNavyPrimary,
                    unfocusedBorderColor = MitraBorder
                )
            )

            // 4 Options (A, B, C, D)
            Text(
                text = "Options (વિકલ્પો):",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MitraTextPrimary
            )

            listOf(
                Triple("A", optionA) { str: String -> optionA = str },
                Triple("B", optionB) { str: String -> optionB = str },
                Triple("C", optionC) { str: String -> optionC = str },
                Triple("D", optionD) { str: String -> optionD = str }
            ).forEach { (label, value, onValChange) ->
                OutlinedTextField(
                    value = value,
                    onValueChange = {
                        onValChange(it)
                        errorMessage = null
                    },
                    label = { Text("Option $label / વિકલ્પ $label") },
                    leadingIcon = {
                        Surface(
                            shape = CircleShape,
                            color = if (correctOption == label) MitraGreen else MitraBgLight,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = label,
                                    color = if (correctOption == label) Color.White else MitraNavyPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("option_${label.lowercase()}_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = if (correctOption == label) MitraGreen else MitraNavyPrimary,
                        unfocusedBorderColor = MitraBorder
                    )
                )
            }

            // Correct Option Selector
            Text(
                text = "Select Correct Answer / સાચો વિકલ્પ પસંદ કરો:",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MitraNavyPrimary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("A", "B", "C", "D").forEach { opt ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        RadioButton(
                            selected = correctOption == opt,
                            onClick = { correctOption = opt },
                            colors = RadioButtonDefaults.colors(selectedColor = MitraGreen),
                            modifier = Modifier.testTag("radio_option_$opt")
                        )
                        Text(
                            text = opt,
                            fontWeight = if (correctOption == opt) FontWeight.Bold else FontWeight.Normal,
                            color = if (correctOption == opt) MitraGreen else MitraTextPrimary
                        )
                    }
                }
            }

            if (!errorMessage.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MitraErrorLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = errorMessage!!,
                        color = MitraError,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            if (!successMessage.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MitraGreenLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = successMessage!!,
                        color = MitraGreen,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            MitraPrimaryButton(
                text = "Save Question / પ્રશ્ન સાચવો",
                onClick = {
                    focusManager.clearFocus()
                    val tId = selectedTestId ?: 0L
                    if (tId <= 0) {
                        errorMessage = "કૃપા કરીને ટેસ્ટ પસંદ કરો (Please select a test)"
                        return@MitraPrimaryButton
                    }
                    if (questionText.isBlank()) {
                        errorMessage = "કૃપા કરીને પ્રશ્ન દાખલ કરો (Please enter question)"
                        return@MitraPrimaryButton
                    }
                    if (optionA.isBlank() || optionB.isBlank() || optionC.isBlank() || optionD.isBlank()) {
                        errorMessage = "બધા ૪ વિકલ્પો (A, B, C, D) ભરવા જરૂરી છે"
                        return@MitraPrimaryButton
                    }

                    isSaving = true
                    errorMessage = null
                    successMessage = null

                    scope.launch {
                        val res = repository.addQuestion(
                            testId = tId,
                            questionText = questionText,
                            optionA = optionA,
                            optionB = optionB,
                            optionC = optionC,
                            optionD = optionD,
                            correctOption = correctOption
                        )
                        isSaving = false
                        if (res is Resource.Success) {
                            successMessage = "પ્રશ્ન સફળતાપૂર્વક સાચવી લીધો! હવે નવો પ્રશ્ન ઉમેરી શકો છો."
                            questionText = ""
                            optionA = ""
                            optionB = ""
                            optionC = ""
                            optionD = ""
                            correctOption = "A"
                            onQuestionAdded()
                        } else if (res is Resource.Error) {
                            errorMessage = res.message
                        }
                    }
                },
                isLoading = isSaving,
                icon = Icons.Default.Add,
                modifier = Modifier.fillMaxWidth(),
                testTag = "save_question_button"
            )
        }
    }
}

