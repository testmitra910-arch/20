package com.example.ui.screens.student

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.QueryBuilder
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuestionItem
import com.example.data.model.User
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraOutlinedButton
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.components.MitraSuccessButton
import com.example.ui.components.OfflineErrorCard
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBlueLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraBorderFocus
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraErrorLight
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyDark
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraOrange
import com.example.ui.theme.MitraOrangeLight
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TakeTestScreen(
    testId: Long,
    testName: String,
    durationMinutes: Int,
    user: User,
    repository: TestMitraRepository,
    onTestFinished: (testId: Long, testName: String, totalQuestions: Int, correctCount: Int, score: Double, answersMapJson: String) -> Unit,
    onCancelTest: () -> Unit
) {
    var questions by remember { mutableStateOf<List<QuestionItem>>(emptyList()) }
    var currentIndex by remember { mutableIntStateOf(0) }
    var isLoading by remember { mutableStateOf(true) }
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showSubmitDialog by remember { mutableStateOf(false) }
    var showExitDialog by remember { mutableStateOf(false) }
    var submitErrorMessage by remember { mutableStateOf<String?>(null) }

    // Map of question ID (or index) -> selected option "A", "B", "C", "D"
    val selectedAnswers = remember { mutableStateMapOf<Long, String>() }

    // Countdown Timer in seconds
    val initialSeconds = remember { (if (durationMinutes > 0) durationMinutes else 15) * 60 }
    var remainingSeconds by remember { mutableIntStateOf(initialSeconds) }

    val scope = rememberCoroutineScope()

    fun loadQuestions() {
        isLoading = true
        errorMessage = null
        scope.launch {
            // Verify if test is active
            val testsRes = repository.getTests()
            if (testsRes is Resource.Success) {
                val currentTest = testsRes.data.firstOrNull { it.id == testId }
                if (currentTest != null && !currentTest.isTestActive) {
                    isLoading = false
                    errorMessage = "આ ટેસ્ટ હાલમાં Deactive (બંધ) છે. તમે આ ટેસ્ટ આપી શકતા નથી.\n(This test has been deactivated by the admin)"
                    return@launch
                }
            }

            when (val res = repository.getQuestionsForTest(testId)) {
                is Resource.Success -> {
                    isLoading = false
                    questions = res.data
                }
                is Resource.Error -> {
                    isLoading = false
                    errorMessage = res.message
                }
                else -> {}
            }
        }
    }

    LaunchedEffect(testId) {
        loadQuestions()
    }

    // Submit handler
    fun performSubmit() {
        if (isSubmitting) return
        isSubmitting = true
        submitErrorMessage = null

        scope.launch {
            var correctCount = 0
            val answersMap = mutableMapOf<String, String>()

            questions.forEach { q ->
                val qId = q.id ?: 0L
                val chosen = selectedAnswers[qId] ?: ""
                answersMap[qId.toString()] = chosen
                if (chosen.isNotBlank() && chosen.equals(q.normalizedCorrectOption(), ignoreCase = true)) {
                    correctCount++
                }
            }

            val finalScore = correctCount.toDouble()
            val userId = user.id ?: 0L

            // Submit to Supabase results table and verify
            val resultSaveRes = repository.submitResult(
                userId = userId,
                testId = testId,
                score = finalScore,
                userMobile = user.mobileNumber
            )

            if (resultSaveRes is Resource.Error) {
                isSubmitting = false
                submitErrorMessage = resultSaveRes.message
                return@launch
            }

            // Serialize answers map to JSON
            val moshi = Moshi.Builder().build()
            val type = Types.newParameterizedType(Map::class.java, String::class.java, String::class.java)
            val adapter = moshi.adapter<Map<String, String>>(type)
            val jsonString = adapter.toJson(answersMap)

            isSubmitting = false
            onTestFinished(
                testId,
                testName,
                questions.size,
                correctCount,
                finalScore,
                jsonString
            )
        }
    }

    // Live Countdown Timer Effect
    LaunchedEffect(isLoading, questions.size) {
        if (!isLoading && questions.isNotEmpty()) {
            while (remainingSeconds > 0) {
                delay(1000L)
                remainingSeconds--
            }
            // Auto submit when time runs out!
            if (remainingSeconds <= 0 && !isSubmitting) {
                performSubmit()
            }
        }
    }

    // Intercept back button to confirm exit
    BackHandler {
        showExitDialog = true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = testName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1
                        )
                        Text(
                            text = if (questions.isNotEmpty()) "Question ${currentIndex + 1} of ${questions.size}" else "Online Test",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { showExitDialog = true },
                        modifier = Modifier.testTag("exit_test_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Exit Test",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    // Timer Chip (with urgent color when under 2 minutes)
                    val minutes = remainingSeconds / 60
                    val seconds = remainingSeconds % 60
                    val isUrgent = remainingSeconds <= 120

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isUrgent) MitraError else MitraGreen,
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .testTag("timer_display")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.QueryBuilder,
                                contentDescription = "Timer",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = String.format("%02d:%02d", minutes, seconds),
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MitraNavyPrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        modifier = Modifier
            .fillMaxSize()
            .testTag("take_test_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MitraBgLight)
        ) {
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                color = MitraNavyPrimary,
                                strokeWidth = 3.5.dp
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Loading test questions...\nપ્રશ્નો લોડ થઈ રહ્યા છે...",
                                color = MitraTextSecondary,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                errorMessage != null -> {
                    OfflineErrorCard(
                        errorMessage = errorMessage,
                        onRetry = { loadQuestions() }
                    )
                }

                questions.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "No Questions in this Test",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MitraTextPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "આ ટેસ્ટમાં હજી કોઈ પ્રશ્નો ઉમેરવામાં આવ્યા નથી.",
                                    fontSize = 13.sp,
                                    color = MitraTextSecondary,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(18.dp))
                                MitraPrimaryButton(
                                    text = "Back to Tests / પાછા જાઓ",
                                    onClick = onCancelTest
                                )
                            }
                        }
                    }
                }

                else -> {
                    val currentQuestion = questions[currentIndex]
                    val qId = currentQuestion.id ?: 0L
                    val selectedOpt = selectedAnswers[qId]

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                    ) {
                        // Progress bar
                        LinearProgressIndicator(
                            progress = { (currentIndex + 1).toFloat() / questions.size.toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp),
                            color = MitraGreen,
                            trackColor = Color(0xFFE2E8F0)
                        )

                        // Question Navigation Palette
                        Surface(
                            color = Color.White,
                            shadowElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                itemsIndexed(questions) { idx, q ->
                                    val itemQId = q.id ?: 0L
                                    val isAnswered = selectedAnswers.containsKey(itemQId) && selectedAnswers[itemQId]?.isNotBlank() == true
                                    val isCurrent = idx == currentIndex

                                    Surface(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .clickable { currentIndex = idx }
                                            .testTag("question_palette_chip_$idx"),
                                        shape = CircleShape,
                                        color = when {
                                            isCurrent -> MitraNavyPrimary
                                            isAnswered -> MitraGreenLight
                                            else -> Color(0xFFF1F5F9)
                                        },
                                        border = if (isAnswered && !isCurrent) BorderStroke(1.5.dp, MitraGreen) else null
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${idx + 1}",
                                                fontSize = 13.sp,
                                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                                color = when {
                                                    isCurrent -> Color.White
                                                    isAnswered -> MitraGreen
                                                    else -> MitraTextSecondary
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Scrollable Question & Options Container
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Question Card
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("question_card"),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(18.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MitraNavyPrimary
                                        ) {
                                            Text(
                                                text = "Q ${currentIndex + 1}",
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }

                                        Text(
                                            text = "${selectedAnswers.size} / ${questions.size} Answered",
                                            fontSize = 12.sp,
                                            color = MitraTextMuted,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text(
                                        text = currentQuestion.questionText,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MitraTextPrimary,
                                        lineHeight = 24.sp
                                    )
                                }
                            }

                            // 4 MCQ Options (A, B, C, D)
                            OptionCard(
                                letter = "A",
                                text = currentQuestion.optionA,
                                isSelected = selectedOpt == "A",
                                onSelect = { selectedAnswers[qId] = "A" },
                                testTag = "option_a_button"
                            )

                            OptionCard(
                                letter = "B",
                                text = currentQuestion.optionB,
                                isSelected = selectedOpt == "B",
                                onSelect = { selectedAnswers[qId] = "B" },
                                testTag = "option_b_button"
                            )

                            OptionCard(
                                letter = "C",
                                text = currentQuestion.optionC,
                                isSelected = selectedOpt == "C",
                                onSelect = { selectedAnswers[qId] = "C" },
                                testTag = "option_c_button"
                            )

                            OptionCard(
                                letter = "D",
                                text = currentQuestion.optionD,
                                isSelected = selectedOpt == "D",
                                onSelect = { selectedAnswers[qId] = "D" },
                                testTag = "option_d_button"
                            )

                            // Clear Choice Button
                            if (selectedOpt != null) {
                                TextButton(
                                    onClick = { selectedAnswers.remove(qId) },
                                    modifier = Modifier
                                        .align(Alignment.End)
                                        .testTag("clear_selection_button")
                                ) {
                                    Text(
                                        text = "Clear Selection / પસંદગી દૂર કરો",
                                        fontSize = 12.sp,
                                        color = MitraOrange,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        // Bottom Navigation & Submit Bar
                        Surface(
                            color = Color.White,
                            shadowElevation = 8.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Previous Button
                                    MitraOutlinedButton(
                                        text = "Prev / અગાઉ",
                                        onClick = {
                                            if (currentIndex > 0) currentIndex--
                                        },
                                        enabled = currentIndex > 0,
                                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                                        modifier = Modifier.weight(1f),
                                        height = 48.dp,
                                        testTag = "prev_question_button"
                                    )

                                    // Next Button or Submit
                                    if (currentIndex < questions.size - 1) {
                                        MitraPrimaryButton(
                                            text = "Next / આગળ",
                                            onClick = {
                                                if (currentIndex < questions.size - 1) currentIndex++
                                            },
                                            icon = Icons.AutoMirrored.Filled.ArrowForward,
                                            modifier = Modifier.weight(1f),
                                            height = 48.dp,
                                            testTag = "next_question_button"
                                        )
                                    } else {
                                        MitraSuccessButton(
                                            text = "Submit / સબમિટ",
                                            onClick = { showSubmitDialog = true },
                                            icon = Icons.Default.Send,
                                            modifier = Modifier.weight(1f),
                                            isLoading = isSubmitting,
                                            testTag = "submit_test_button"
                                        )
                                    }
                                }

                                // Quick Submit Bar if not on last page
                                if (currentIndex < questions.size - 1) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    MitraSuccessButton(
                                        text = "Submit Test / ટેસ્ટ સબમિટ કરો (${selectedAnswers.size}/${questions.size} answered)",
                                        onClick = { showSubmitDialog = true },
                                        icon = Icons.Default.Send,
                                        modifier = Modifier.fillMaxWidth(),
                                        isLoading = isSubmitting,
                                        testTag = "quick_submit_test_button"
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Submit Confirmation Dialog
    if (showSubmitDialog) {
        val answeredCount = selectedAnswers.size
        val unansweredCount = questions.size - answeredCount

        AlertDialog(
            onDismissRequest = { if (!isSubmitting) showSubmitDialog = false },
            title = {
                Text(
                    text = "Submit Test? / ટેસ્ટ સબમિટ કરવો છે?",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MitraTextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Total Questions / કુલ પ્રશ્નો: ${questions.size}",
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Answered / આપેલ ઉત્તર: $answeredCount",
                        color = MitraGreen,
                        fontWeight = FontWeight.Bold
                    )
                    if (unansweredCount > 0) {
                        Text(
                            text = "Unanswered / બાકી રહેલા: $unansweredCount",
                            color = MitraOrange,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Are you sure you want to submit? After submission you will get your instant result.\nશું તમે ખરેખર ટેસ્ટ સબમિટ કરવા માંગો છો?",
                        fontSize = 13.sp,
                        color = MitraTextSecondary
                    )
                }
            },
            confirmButton = {
                MitraSuccessButton(
                    text = "Confirm & Submit / સબમિટ કરો",
                    onClick = {
                        showSubmitDialog = false
                        performSubmit()
                    },
                    isLoading = isSubmitting,
                    testTag = "confirm_submit_button"
                )
            },
            dismissButton = {
                TextButton(
                    onClick = { showSubmitDialog = false },
                    enabled = !isSubmitting,
                    modifier = Modifier.testTag("cancel_submit_button")
                ) {
                    Text("Continue Test / ટેસ્ટ ચાલુ રાખો", color = MitraTextSecondary)
                }
            }
        )
    }

    // Exit Confirmation Dialog
    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = {
                Text("Exit Test? / ટેસ્ટ છોડવો છે?", fontWeight = FontWeight.Bold)
            },
            text = {
                Text("If you leave now, your progress will not be saved.\nજો તમે અત્યારે બહાર નીકળશો તો પરિણામ સેવ થશે નહીં.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showExitDialog = false
                        onCancelTest()
                    },
                    modifier = Modifier.testTag("confirm_exit_button")
                ) {
                    Text("Exit / બહાર નીકળો", color = MitraError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showExitDialog = false },
                    modifier = Modifier.testTag("cancel_exit_button")
                ) {
                    Text("Stay / ચાલુ રાખો")
                }
            }
        )
    }

    // Submit Failure / Error Dialog
    if (submitErrorMessage != null) {
        AlertDialog(
            onDismissRequest = { submitErrorMessage = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MitraError
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "સબમિશન નિષ્ફળ (Submission Failed)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MitraError
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = submitErrorMessage ?: "પરિણામ સેવ કરવામાં મુશ્કેલી આવી છે.",
                        color = MitraTextPrimary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "કૃપા કરીને ઇન્ટરનેટ કનેક્શન ચકાસો અને ફરીથી સબમિટ કરો.",
                        color = MitraTextSecondary,
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                MitraSuccessButton(
                    text = "Retry / ફરી સબમિટ કરો",
                    onClick = {
                        submitErrorMessage = null
                        performSubmit()
                    },
                    modifier = Modifier.testTag("retry_submit_button")
                )
            },
            dismissButton = {
                TextButton(
                    onClick = { submitErrorMessage = null },
                    modifier = Modifier.testTag("dismiss_submit_error_button")
                ) {
                    Text("Cancel / રદ કરો")
                }
            }
        )
    }
}

@Composable
private fun OptionCard(
    letter: String,
    text: String,
    isSelected: Boolean,
    onSelect: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSelect() }
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MitraBlueLight else Color.White
        ),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) MitraNavyPrimary else MitraBorder
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Option Letter Circle (e.g. A, B, C, D)
            Surface(
                modifier = Modifier.size(34.dp),
                shape = CircleShape,
                color = if (isSelected) MitraNavyPrimary else Color(0xFFF1F5F9)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = letter,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else MitraNavyPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Text(
                text = text,
                fontSize = 15.sp,
                color = if (isSelected) MitraNavyDark else MitraTextPrimary,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                modifier = Modifier.weight(1f),
                lineHeight = 21.sp
            )

            Spacer(modifier = Modifier.width(8.dp))

            RadioButton(
                selected = isSelected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(
                    selectedColor = MitraNavyPrimary,
                    unselectedColor = MitraBorder
                )
            )
        }
    }
}
